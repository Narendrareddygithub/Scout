
import { GoogleGenAI, Type } from "@google/genai";
import { FeedbackItem } from "../types";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing");
  }
  return new GoogleGenAI({ apiKey });
};

// 1. The Ingestor Agent Logic: Maps CSV headers to our schema
export const mapCsvHeaders = async (headers: string[], previewRows: any[]): Promise<Record<string, string>> => {
  const ai = getAiClient();
  
  const prompt = `
    You are the "Ingestor Agent" for a Voice of Customer analytics platform.
    Your job is to map the headers from a user-uploaded CSV to our internal schema.
    
    Internal Schema Fields:
    - "originalText": The main content of the feedback/review.
    - "date": The date of the feedback.
    - "rating": Numeric score (1-5 or 1-10).
    - "source": Where it came from (e.g., Twitter, Email).

    Available CSV Headers:
    ${JSON.stringify(headers)}

    Sample Data:
    ${JSON.stringify(previewRows.slice(0, 2))}

    Return a JSON object where keys are the Internal Schema Fields and values are the EXACT header names from the "Available CSV Headers" list.
    If a field doesn't have a clear match, exclude it.
    The "originalText" field is MANDATORY.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            originalText: { type: Type.STRING },
            date: { type: Type.STRING },
            rating: { type: Type.STRING },
            source: { type: Type.STRING },
          },
          required: ['originalText']
        }
      }
    });

    if (!response.text) throw new Error("No response from Ingestor Agent");
    
    const rawMapping = JSON.parse(response.text);
    const validatedMapping: Record<string, string> = {};
    
    // Create lookup maps for robust matching (exact and case-insensitive)
    const exactHeaders = new Set(headers);
    const lowerHeaders = new Map(headers.map(h => [h.toLowerCase(), h]));

    // Validate and fix mapping
    for (const [key, value] of Object.entries(rawMapping)) {
      const valStr = String(value); // Ensure it's a string
      
      if (exactHeaders.has(valStr)) {
        validatedMapping[key] = valStr;
      } else if (lowerHeaders.has(valStr.toLowerCase())) {
        // Auto-correct casing issues (e.g. "review" -> "Review")
        validatedMapping[key] = lowerHeaders.get(valStr.toLowerCase())!;
      } else if (lowerHeaders.has(valStr.trim().toLowerCase())) {
         // Auto-correct trimming issues
         validatedMapping[key] = lowerHeaders.get(valStr.trim().toLowerCase())!;
      } else {
        console.warn(`Ingestor Agent mapped '${key}' to non-existent header '${valStr}'. Ignoring.`);
      }
    }

    // Last resort fallback for mandatory field
    if (!validatedMapping.originalText) {
        console.warn("Ingestor Agent failed to map originalText. Attempting heuristic fallback.");
        const fallback = headers.find(h => 
            h.toLowerCase().includes('review') || 
            h.toLowerCase().includes('text') || 
            h.toLowerCase().includes('comment') ||
            h.toLowerCase().includes('feedback')
        );
        if (fallback) {
            validatedMapping.originalText = fallback;
        } else {
            throw new Error("Ingestion Failed: Could not identify a column for feedback text. Please check your CSV headers.");
        }
    }

    return validatedMapping;

  } catch (error) {
    console.error("Ingestor Agent failed:", error);
    throw error;
  }
};

// 2. The Critic Agent Logic: Validates data quality
export const critiqueDataset = async (sampleRows: any[], mapping: Record<string, string>): Promise<{ valid: boolean; reason: string }> => {
  const ai = getAiClient();

  // Prepare a safer minified version for the LLM
  const minified = sampleRows.map(r => {
    // Robust check: Ensure the mapped key exists in the row. 
    const textContent = mapping.originalText && r[mapping.originalText] !== undefined 
        ? r[mapping.originalText] 
        : "<<MISSING COLUMN MAPPING>>";

    return {
      text: textContent,
      date: mapping.date ? (r[mapping.date] || 'N/A') : 'N/A'
    };
  });

  const prompt = `
    You are the "Critic Agent". Validate this dataset sample.
    
    CRITICAL:
    1. If the 'text' field contains "<<MISSING COLUMN MAPPING>>", you MUST reject with "Invalid column mapping".
    2. Does the 'text' look like valid customer feedback (natural language)?
    3. It should not be just numbers, IDs, or system codes.
    
    Sample:
    ${JSON.stringify(minified)}
    
    Return JSON: { "valid": boolean, "reason": string }
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
              valid: { type: Type.BOOLEAN },
              reason: { type: Type.STRING }
          },
          required: ['valid', 'reason']
        }
      }
    });

    if (!response.text) return { valid: true, reason: "Critic passed by default (empty response)." };
    
    const result = JSON.parse(response.text);
    // Fallback if LLM violates schema slightly
    return {
        valid: result.valid,
        reason: result.reason || "Unspecified reason by Critic Agent."
    };
  } catch (error) {
      console.error("Critic Agent failed:", error);
      return { valid: false, reason: "Critic Agent encountered a system error during validation." };
  }
};

// 3. The Analyst Agent Logic: Enriches data (Sentiment & Topics)
export const analyzeBatch = async (rows: any[], mapping: Record<string, string>): Promise<FeedbackItem[]> => {
  const ai = getAiClient();
  
  // Prepare a minified version of data for the LLM
  const minifiedData = rows.map((row, idx) => ({
    id: idx,
    text: row[mapping.originalText] || "", // Safe access
    date: mapping.date ? row[mapping.date] : new Date().toISOString(),
  })).filter(item => item.text && item.text.trim().length > 0); // Filter empty

  if (minifiedData.length === 0) return [];

  const prompt = `
    You are the "Analyst Agent". Analyze the following customer feedback items.
    For each item:
    1. Determine sentiment (Positive, Neutral, Negative).
    2. Extract up to 2 key topics (e.g., "Pricing", "UX", "Bugs").
    
    Data:
    ${JSON.stringify(minifiedData)}
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.INTEGER },
            sentiment: { type: Type.STRING, enum: ['Positive', 'Neutral', 'Negative'] },
            topics: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    }
  });

  if (!response.text) return [];

  const analysisResults = JSON.parse(response.text);

  // Merge analysis with original data
  return minifiedData.map((item: any) => {
    const analysis = analysisResults.find((a: any) => a.id === item.id);
    // Retrieve original row using ID (assuming index match, but robust logic is safer)
    const originalRow = rows[item.id];
    
    return {
      id: crypto.randomUUID(),
      originalText: item.text,
      date: item.date,
      sentiment: analysis?.sentiment || 'Neutral',
      topics: analysis?.topics || [],
      rating: mapping.rating && originalRow[mapping.rating] ? Number(originalRow[mapping.rating]) : undefined
    };
  });
};

// 4. Chat Agent: Talk to your data
export const askScout = async (query: string, contextItems: FeedbackItem[]) => {
  const ai = getAiClient();

  // Naive RAG: Just taking the top 50 items for context to fit in context window for this demo
  const contextStr = contextItems.slice(0, 50).map(item => 
    `[${item.date}] (${item.sentiment}) ${item.originalText}`
  ).join('\n');

  const prompt = `
    You are "Scout", an intelligent Voice of Customer assistant.
    Answer the user's question based strictly on the provided feedback data.
    
    User Query: "${query}"
    
    Context Data:
    ${contextStr}
    
    Be concise, professional, and cite specific examples if possible.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
  });

  return response.text || "I couldn't generate an answer.";
};
