
export enum ProcessingStatus {
  IDLE = 'IDLE',
  ANALYZING_STRUCTURE = 'ANALYZING_STRUCTURE',
  PROCESSING_ROWS = 'PROCESSING_ROWS',
  COMPLETE = 'COMPLETE',
  ERROR = 'ERROR'
}

export interface FeedbackItem {
  id: string;
  originalText: string;
  date: string;
  sentiment: 'Positive' | 'Neutral' | 'Negative';
  topics: string[];
  source?: string;
  rating?: number;
}

export interface DatasetStats {
  total: number;
  positive: number;
  neutral: number;
  negative: number;
  topTopics: { topic: string; count: number }[];
}

export interface IngestionResult {
  mappedHeaders: Record<string, string>;
  items: FeedbackItem[];
}

export enum View {
  DASHBOARD = 'DASHBOARD',
  UPLOAD = 'UPLOAD',
  CHAT = 'CHAT',
}

export interface AgentLogEntry {
  id: string;
  timestamp: Date;
  agent: 'Ingestor' | 'Analyst' | 'Critic' | 'DevOps';
  message: string;
  status: 'info' | 'success' | 'warning' | 'error';
}
