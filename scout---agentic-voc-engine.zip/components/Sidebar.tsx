import React from 'react';
import { LayoutDashboard, UploadCloud, MessageSquareText, Box } from 'lucide-react';
import { View } from '../types';

interface SidebarProps {
  currentView: View;
  onChangeView: (view: View) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onChangeView }) => {
  const navItems = [
    { id: View.UPLOAD, label: 'Ingest Data', icon: UploadCloud },
    { id: View.DASHBOARD, label: 'Pulse Dashboard', icon: LayoutDashboard },
    { id: View.CHAT, label: 'Ask Scout', icon: MessageSquareText },
  ];

  return (
    <div className="w-20 lg:w-64 bg-slate-900 border-r border-slate-800 flex flex-col h-screen fixed left-0 top-0 z-50 transition-all duration-300">
      <div className="h-20 flex items-center justify-center lg:justify-start lg:px-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="bg-scout-600 p-2 rounded-lg">
             <Box className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold text-white hidden lg:block tracking-tight">Scout</span>
        </div>
      </div>

      <nav className="flex-1 py-8 px-2 lg:px-4 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onChangeView(item.id)}
            className={`
              w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200
              ${currentView === item.id 
                ? 'bg-scout-500/10 text-scout-400 border border-scout-500/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }
            `}
          >
            <item.icon className={`w-6 h-6 ${currentView === item.id ? 'text-scout-400' : ''}`} />
            <span className="font-medium hidden lg:block">{item.label}</span>
            
            {currentView === item.id && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-scout-400 shadow-[0_0_8px_rgba(74,222,128,0.5)] hidden lg:block" />
            )}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800 hidden lg:block">
        <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 font-medium mb-1">System Status</p>
          <div className="flex items-center gap-2">
             <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
             <span className="text-xs text-green-400">Agents Active</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
