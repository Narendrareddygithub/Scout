
import React, { useEffect, useRef, useState } from 'react';
import { AgentLogEntry } from '../types';
import { Terminal, Shield, Brain, FileInput, Cpu, ChevronDown, ChevronUp, Activity } from 'lucide-react';

interface AgentConsoleProps {
  logs: AgentLogEntry[];
}

const AgentConsole: React.FC<AgentConsoleProps> = ({ logs }) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [isExpanded, setIsExpanded] = useState(true);

  useEffect(() => {
    if (isExpanded) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs, isExpanded]);

  const getAgentColor = (agent: string) => {
    switch (agent) {
      case 'Ingestor': return 'text-blue-400';
      case 'Analyst': return 'text-purple-400';
      case 'Critic': return 'text-rose-400';
      case 'DevOps': return 'text-orange-400';
      default: return 'text-slate-400';
    }
  };

  const getAgentIcon = (agent: string) => {
     switch (agent) {
      case 'Ingestor': return <FileInput className="w-3.5 h-3.5" />;
      case 'Analyst': return <Brain className="w-3.5 h-3.5" />;
      case 'Critic': return <Shield className="w-3.5 h-3.5" />;
      case 'DevOps': return <Cpu className="w-3.5 h-3.5" />;
      default: return <Terminal className="w-3.5 h-3.5" />;
    }
  };

  const getMessageStyle = (status: string) => {
    switch (status) {
      case 'success': return 'text-emerald-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-amber-400';
      default: return 'text-slate-300';
    }
  };

  return (
    <div 
      className={`
        fixed bottom-0 left-0 lg:left-64 right-0 
        bg-slate-950 border-t border-slate-800 shadow-[0_-5px_20px_rgba(0,0,0,0.5)] 
        z-40 transition-all duration-300 ease-in-out flex flex-col
        ${isExpanded ? 'h-64' : 'h-9'}
      `}
    >
      {/* Header Bar */}
      <div 
        className="min-h-[36px] h-9 bg-slate-900/95 backdrop-blur px-4 flex items-center justify-between border-b border-slate-800 cursor-pointer hover:bg-slate-800 transition-colors group"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          {isExpanded ? (
            <ChevronDown className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
          ) : (
             <ChevronUp className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
          )}
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.15em] flex items-center gap-2">
             HIVE ACTIVITY
          </span>
        </div>
        
        {/* Window Controls Decoration */}
        <div className="flex gap-1.5 opacity-50 group-hover:opacity-100 transition-opacity">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-600" />
          <div className="w-2.5 h-2.5 rounded-full bg-slate-600" />
          <div className="w-2.5 h-2.5 rounded-full bg-slate-600" />
        </div>
      </div>
      
      {/* Console Content */}
      <div className={`flex-1 overflow-y-auto p-4 font-mono text-xs space-y-2 custom-scrollbar bg-slate-950/95 ${!isExpanded && 'hidden'}`}>
        {logs.length === 0 && (
          <div className="text-slate-600 italic flex items-center gap-2">
            <Activity className="w-3 h-3" />
            <span>System idle. Waiting for tasks...</span>
          </div>
        )}
        {logs.map((log) => (
          <div key={log.id} className="flex items-start gap-4 animate-in fade-in slide-in-from-left-2 duration-300 group border-l-2 border-transparent hover:border-slate-800 pl-2 -ml-2 py-0.5">
             {/* Vertical decorative line/marker similar to screenshot implies structure */}
             <div className={`w-1 h-1 mt-1.5 rounded-full flex-shrink-0 ${getAgentColor(log.agent).replace('text-', 'bg-')}`} />
             
            <div className="flex items-center gap-2 w-24 flex-shrink-0">
               <span className={`opacity-75 ${getAgentColor(log.agent)}`}>
                {getAgentIcon(log.agent)}
               </span>
               <span className={`font-bold ${getAgentColor(log.agent)}`}>
                   {log.agent}
               </span>
            </div>
            <span className={`flex-1 leading-relaxed ${getMessageStyle(log.status)}`}>
              {log.message}
            </span>
             <span className="text-slate-700 text-[10px] opacity-0 group-hover:opacity-100 transition-opacity select-none">
              {log.timestamp.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  );
};

export default AgentConsole;
