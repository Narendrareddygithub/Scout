import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { FeedbackItem, DatasetStats } from '../types';
import { Activity, ThumbsUp, ThumbsDown, MessageSquare } from 'lucide-react';

interface DashboardProps {
  data: FeedbackItem[];
}

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  // Calculate Stats
  const stats: DatasetStats = React.useMemo(() => {
    const s = {
      total: data.length,
      positive: data.filter(i => i.sentiment === 'Positive').length,
      neutral: data.filter(i => i.sentiment === 'Neutral').length,
      negative: data.filter(i => i.sentiment === 'Negative').length,
      topTopics: [] as { topic: string; count: number }[]
    };

    const topicMap: Record<string, number> = {};
    data.forEach(item => {
      item.topics.forEach(t => {
        topicMap[t] = (topicMap[t] || 0) + 1;
      });
    });

    s.topTopics = Object.entries(topicMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([topic, count]) => ({ topic, count }));

    return s;
  }, [data]);

  const sentimentData = [
    { name: 'Positive', value: stats.positive, color: '#4ade80' },
    { name: 'Neutral', value: stats.neutral, color: '#94a3b8' },
    { name: 'Negative', value: stats.negative, color: '#f87171' },
  ];

  if (data.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-500">
        <Activity className="w-16 h-16 mb-4 opacity-20" />
        <p>No data available. Upload a CSV to see the Pulse.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <div className="flex items-center gap-3 text-slate-400 mb-2">
            <MessageSquare className="w-5 h-5" />
            <span className="text-sm font-medium">Total Feedback</span>
          </div>
          <p className="text-3xl font-bold text-white">{stats.total}</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <div className="flex items-center gap-3 text-green-400 mb-2">
            <ThumbsUp className="w-5 h-5" />
            <span className="text-sm font-medium">Positive</span>
          </div>
          <p className="text-3xl font-bold text-white">{stats.positive}</p>
          <p className="text-xs text-slate-500 mt-1">{((stats.positive / stats.total) * 100).toFixed(1)}%</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <div className="flex items-center gap-3 text-red-400 mb-2">
            <ThumbsDown className="w-5 h-5" />
            <span className="text-sm font-medium">Negative</span>
          </div>
          <p className="text-3xl font-bold text-white">{stats.negative}</p>
          <p className="text-xs text-slate-500 mt-1">{((stats.negative / stats.total) * 100).toFixed(1)}%</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <div className="flex items-center gap-3 text-scout-400 mb-2">
            <Activity className="w-5 h-5" />
            <span className="text-sm font-medium">NPS (Est.)</span>
          </div>
          <p className="text-3xl font-bold text-white">
            {Math.round(((stats.positive - stats.negative) / stats.total) * 100)}
          </p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Sentiment Distribution */}
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <h3 className="text-lg font-semibold text-white mb-6">Sentiment Distribution</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }} 
                    itemStyle={{ color: '#f8fafc' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            {sentimentData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-slate-300">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Topics */}
        <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl">
          <h3 className="text-lg font-semibold text-white mb-6">Trending Topics</h3>
          <div className="h-64">
             <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={stats.topTopics}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
              >
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="topic" width={100} tick={{ fill: '#94a3b8', fontSize: 12 }} />
                <Tooltip 
                    cursor={{fill: '#334155', opacity: 0.4}}
                    contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }} 
                />
                <Bar dataKey="count" fill="#86efac" radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Feed */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
        <div className="p-6 border-b border-slate-700">
            <h3 className="text-lg font-semibold text-white">Deep Dive</h3>
        </div>
        <div className="divide-y divide-slate-700 max-h-[400px] overflow-y-auto">
            {data.map((item) => (
                <div key={item.id} className="p-4 hover:bg-slate-750 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                            <span className={`
                                px-2 py-1 rounded text-xs font-medium
                                ${item.sentiment === 'Positive' ? 'bg-green-500/20 text-green-400' : 
                                  item.sentiment === 'Negative' ? 'bg-red-500/20 text-red-400' : 
                                  'bg-slate-500/20 text-slate-400'}
                            `}>
                                {item.sentiment}
                            </span>
                            {item.topics.map(t => (
                                <span key={t} className="text-xs text-slate-500 border border-slate-700 px-2 py-0.5 rounded-full">
                                    {t}
                                </span>
                            ))}
                        </div>
                        <span className="text-xs text-slate-500">{item.date}</span>
                    </div>
                    <p className="text-slate-300 text-sm leading-relaxed">{item.originalText}</p>
                </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
