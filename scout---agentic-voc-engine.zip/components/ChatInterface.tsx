import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, AlertTriangle } from 'lucide-react';
import { FeedbackItem } from '../types';
import { askScout } from '../services/gemini';

interface ChatInterfaceProps {
  data: FeedbackItem[];
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ data }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: 'welcome', role: 'assistant', content: 'Hi! I\'m Scout. I\'ve analyzed your data. Ask me anything, like "Why are customers churning?" or "Summarize the positive feedback".' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    if (data.length === 0) {
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', content: input }]);
        setTimeout(() => {
            setMessages(prev => [...prev, { id: 'no-data', role: 'assistant', content: "I don't have any data yet. Please upload a CSV file in the Upload tab first." }]);
        }, 500);
        setInput('');
        return;
    }

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    try {
      const responseText = await askScout(userMsg.content, data);
      
      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: responseText };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      const errorMsg: Message = { id: 'error', role: 'assistant', content: "Sorry, I encountered an error while processing your request." };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] bg-slate-900 rounded-2xl overflow-hidden border border-slate-700 shadow-2xl">
      {/* Chat Header */}
      <div className="bg-slate-800 p-4 border-b border-slate-700 flex items-center gap-3">
        <div className="bg-scout-500 p-2 rounded-lg">
            <Sparkles className="w-5 h-5 text-white" />
        </div>
        <div>
            <h3 className="text-white font-medium">Scout Assistant</h3>
            <p className="text-xs text-slate-400">Powered by Gemini 3 Pro</p>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            <div className={`
              w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
              ${msg.role === 'user' ? 'bg-slate-700' : 'bg-scout-600'}
            `}>
              {msg.role === 'user' ? <User className="w-5 h-5 text-slate-300" /> : <Bot className="w-5 h-5 text-white" />}
            </div>
            
            <div className={`
              max-w-[80%] rounded-2xl p-4 text-sm leading-relaxed
              ${msg.role === 'user' 
                ? 'bg-slate-700 text-slate-100 rounded-tr-none' 
                : 'bg-slate-800 border border-slate-700 text-slate-300 rounded-tl-none shadow-sm'
              }
            `}>
              {msg.content}
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex gap-4">
             <div className="w-8 h-8 rounded-full bg-scout-600 flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-white" />
            </div>
            <div className="bg-slate-800 border border-slate-700 rounded-2xl rounded-tl-none p-4 flex items-center gap-2">
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-2 h-2 bg-slate-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-slate-800 border-t border-slate-700">
        {data.length === 0 && (
            <div className="mb-4 flex items-center gap-2 text-amber-400 text-xs bg-amber-900/20 p-2 rounded border border-amber-900/50">
                <AlertTriangle className="w-4 h-4" />
                Data not loaded. Chat responses will be generic.
            </div>
        )}
        <div className="relative">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Ask about trends, issues, or summaries..."
            className="w-full bg-slate-900 text-white rounded-xl pl-4 pr-12 py-3 border border-slate-700 focus:outline-none focus:border-scout-500 focus:ring-1 focus:ring-scout-500 transition-all"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-scout-600 hover:bg-scout-500 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-lg text-white transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        <p className="text-center text-xs text-slate-500 mt-2">
          Scout may display inaccurate info, including about people, so double-check its responses.
        </p>
      </div>
    </div>
  );
};

export default ChatInterface;
