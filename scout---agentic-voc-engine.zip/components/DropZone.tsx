import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle, Loader2, CheckCircle2 } from 'lucide-react';
import { ProcessingStatus } from '../types';

interface DropZoneProps {
  onFileUpload: (file: File) => void;
  status: ProcessingStatus;
  error?: string | null;
}

const DropZone: React.FC<DropZoneProps> = ({ onFileUpload, status, error }) => {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.type === "text/csv" || file.name.endsWith('.csv')) {
        onFileUpload(file);
      } else {
        alert("Please upload a CSV file.");
      }
    }
  }, [onFileUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onFileUpload(e.target.files[0]);
    }
  }, [onFileUpload]);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          relative group cursor-pointer
          border-2 border-dashed rounded-2xl p-12
          transition-all duration-300 ease-in-out
          flex flex-col items-center justify-center text-center
          ${isDragOver 
            ? 'border-scout-500 bg-scout-500/10 shadow-[0_0_30px_rgba(34,197,94,0.2)]' 
            : 'border-slate-700 bg-slate-800/50 hover:border-scout-500/50 hover:bg-slate-800'
          }
        `}
      >
        <input
          type="file"
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          accept=".csv"
          onChange={handleFileSelect}
          disabled={status !== ProcessingStatus.IDLE && status !== ProcessingStatus.COMPLETE && status !== ProcessingStatus.ERROR}
        />

        {status === ProcessingStatus.IDLE || status === ProcessingStatus.ERROR ? (
          <>
            <div className={`p-4 rounded-full mb-4 transition-colors duration-300 ${isDragOver ? 'bg-scout-500/20 text-scout-400' : 'bg-slate-700/50 text-slate-400 group-hover:text-scout-400'}`}>
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold text-slate-200 mb-2">
              Drop your feedback CSV here
            </h3>
            <p className="text-slate-400 text-sm max-w-xs">
              The Ingestor Agent will automatically detect columns for text, date, and ratings.
            </p>
          </>
        ) : status === ProcessingStatus.COMPLETE ? (
           <>
            <div className="p-4 rounded-full mb-4 bg-scout-500/20 text-scout-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold text-scout-400 mb-2">
              Processing Complete
            </h3>
            <p className="text-slate-400 text-sm">
              Your data has been analyzed. Head to the dashboard.
            </p>
           </>
        ) : (
          <>
            <div className="p-4 rounded-full mb-4 bg-indigo-500/20 text-indigo-400 animate-pulse">
              <Loader2 className="w-8 h-8 animate-spin" />
            </div>
            <h3 className="text-xl font-semibold text-indigo-300 mb-2">
              {status === ProcessingStatus.ANALYZING_STRUCTURE ? "Agent analyzing CSV structure..." : "Analyst Agent extracting insights..."}
            </h3>
            <p className="text-slate-400 text-sm">
              This uses Gemini 2.5 Flash for rapid processing.
            </p>
          </>
        )}
      </div>

      {error && (
        <div className="mt-4 p-4 bg-red-900/20 border border-red-900/50 rounded-xl flex items-center gap-3 text-red-400">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm">{error}</p>
        </div>
      )}

      {/* Sample Data Helper */}
      {status === ProcessingStatus.IDLE && (
        <div className="mt-8 text-center">
           <p className="text-slate-500 text-sm mb-2">Don't have a file?</p>
           <button 
            onClick={(e) => {
                e.stopPropagation();
                // Create a dummy CSV file
                const csvContent = `Review Text,Date,Star Rating,Source\n"The new update is amazing, love the speed!",2023-10-01,5,Twitter\n"I hate the login screen, it crashes constantly.",2023-10-02,1,Support Ticket\n"Pricing is a bit high but features are good.",2023-10-03,4,G2\n"Customer support never replied to me.",2023-10-04,1,Email\n"Best SaaS I have used in years.",2023-10-05,5,ProductHunt`;
                const file = new File([csvContent], "sample_feedback.csv", { type: "text/csv" });
                onFileUpload(file);
            }}
            className="text-scout-400 hover:text-scout-300 text-sm underline cursor-pointer z-10 relative"
           >
             Use sample CSV
           </button>
        </div>
      )}
    </div>
  );
};

export default DropZone;
