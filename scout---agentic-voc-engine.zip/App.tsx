
import React, { useState, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import DropZone from './components/DropZone';
import Dashboard from './components/Dashboard';
import ChatInterface from './components/ChatInterface';
import AgentConsole from './components/AgentConsole';
import { View, ProcessingStatus, FeedbackItem, AgentLogEntry } from './types';
import { mapCsvHeaders, analyzeBatch, critiqueDataset } from './services/gemini';
import { parseCSV } from './services/csv';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.UPLOAD);
  const [processingStatus, setProcessingStatus] = useState<ProcessingStatus>(ProcessingStatus.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<FeedbackItem[]>([]);
  const [logs, setLogs] = useState<AgentLogEntry[]>([]);

  const addLog = (agent: AgentLogEntry['agent'], message: string, status: AgentLogEntry['status'] = 'info') => {
    setLogs(prev => [...prev, {
      id: crypto.randomUUID(),
      timestamp: new Date(),
      agent,
      message,
      status
    }]);
  };

  // Orchestrator: Logic to handle file upload -> Ingestor Agent -> Analyst Agent
  const handleFileUpload = useCallback(async (file: File) => {
    setProcessingStatus(ProcessingStatus.ANALYZING_STRUCTURE);
    setError(null);
    setLogs([]); // Clear logs on new upload
    
    try {
      addLog('Ingestor', `Receiving file: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`);
      
      const text = await file.text();
      addLog('Ingestor', 'File stream read successfully. Parsing CSV structure...', 'info');

      // 1. Robust Parsing
      const parsedRawData = parseCSV(text);
      if (parsedRawData.length === 0) {
        throw new Error("CSV appears to be empty or malformed.");
      }
      addLog('Ingestor', `Parsed ${parsedRawData.length} rows. Identifying schema...`, 'success');

      // 2. Header Mapping (Ingestor Agent)
      // Take the keys from the first row as headers since parseCSV returns objects
      const headers = Object.keys(parsedRawData[0]);
      const sampleRows = parsedRawData.slice(0, 3);
      
      // NEW: Pass parsed headers and sample rows directly to the agent
      const mapping = await mapCsvHeaders(headers, sampleRows);
      addLog('Ingestor', `Schema mapped: ${JSON.stringify(mapping)}`, 'success');

      // 3. Critic Loop (Validation)
      addLog('Critic', 'Validating data quality before analysis...', 'info');
      const critique = await critiqueDataset(sampleRows, mapping);
      
      if (!critique.valid) {
         addLog('Critic', `Data validation failed: ${critique.reason}`, 'error');
         throw new Error(`Critic Agent rejected dataset: ${critique.reason}`);
      }
      addLog('Critic', 'Data quality check passed. Proceeding to analysis.', 'success');

      setProcessingStatus(ProcessingStatus.PROCESSING_ROWS);

      // 4. Analysis (Analyst Agent) - BATCH PROCESSING
      addLog('Analyst', 'Initializing batch processing with Gemini 2.5 Flash...', 'info');
      
      const BATCH_SIZE = 20; // Safe limit for output tokens per request
      let allAnalyzedData: FeedbackItem[] = [];
      const totalBatches = Math.ceil(parsedRawData.length / BATCH_SIZE);

      for (let i = 0; i < parsedRawData.length; i += BATCH_SIZE) {
        const batchIndex = Math.floor(i / BATCH_SIZE) + 1;
        const batchData = parsedRawData.slice(i, i + BATCH_SIZE);
        
        addLog('Analyst', `Processing batch ${batchIndex}/${totalBatches} (${batchData.length} items)...`, 'info');

        try {
            // Add a small delay to avoid hitting rate limits too hard if user has many batches
            if (i > 0) await new Promise(resolve => setTimeout(resolve, 1000));

            const batchResults = await analyzeBatch(batchData, mapping);
            allAnalyzedData = [...allAnalyzedData, ...batchResults];
            
            addLog('Analyst', `Batch ${batchIndex} complete.`, 'success');
        } catch (error) {
            console.error(`Batch ${batchIndex} failed:`, error);
            addLog('Analyst', `Batch ${batchIndex} failed. Skipping partial data.`, 'warning');
        }
      }

      if (allAnalyzedData.length === 0) {
          throw new Error("Analyst Agent failed to process any data rows.");
      }
      
      addLog('Analyst', `Analysis complete. Total items processed: ${allAnalyzedData.length}.`, 'success');
      
      setData(allAnalyzedData);
      setProcessingStatus(ProcessingStatus.COMPLETE);
      
      // Auto-switch to dashboard after short delay
      setTimeout(() => {
        addLog('DevOps', 'Deployment to Dashboard complete.', 'success');
        setCurrentView(View.DASHBOARD);
      }, 2000);

    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || "Failed to process file.";
      setError(errMsg);
      addLog('DevOps', `System Error: ${errMsg}`, 'error');
      setProcessingStatus(ProcessingStatus.ERROR);
    }
  }, []);

  const renderContent = () => {
    switch (currentView) {
      case View.UPLOAD:
        return (
          <div className="flex flex-col items-center justify-center h-full space-y-8 p-8 pb-48">
            <div className="text-center max-w-xl animate-in fade-in-50 duration-500">
              <h1 className="text-4xl font-bold text-white mb-4">Agentic Ingestion</h1>
              <p className="text-slate-400 text-lg">
                Drag & Drop your raw customer feedback. <br />
                The <span className="text-scout-400 font-mono">Hive</span> will handle the rest.
              </p>
            </div>
            <DropZone 
              onFileUpload={handleFileUpload} 
              status={processingStatus}
              error={error}
            />
          </div>
        );
      case View.DASHBOARD:
        return (
          <div className="p-8 h-full overflow-y-auto pb-56 custom-scrollbar">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-white">Pulse Dashboard</h1>
                <p className="text-slate-400">Real-time sentiment and topic signals.</p>
              </div>
              {data.length > 0 && (
                 <span className="bg-scout-900 text-scout-400 px-3 py-1 rounded-full text-xs font-mono border border-scout-800">
                    {data.length} items analyzed
                 </span>
              )}
            </div>
            <Dashboard data={data} />
          </div>
        );
      case View.CHAT:
        return (
          <div className="p-8 h-full pb-56">
            <h1 className="text-3xl font-bold text-white mb-2">Ask Scout</h1>
            <p className="text-slate-400 mb-6">Your data analyst agent is ready to answer questions.</p>
            <ChatInterface data={data} />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 font-sans selection:bg-scout-500/30">
      <Sidebar currentView={currentView} onChangeView={setCurrentView} />
      <main className="flex-1 ml-20 lg:ml-64 relative h-full">
        {/* Top bar decoration */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-scout-600 via-blue-500 to-purple-500 opacity-50" />
        
        {renderContent()}

        {/* The Hive Console - Always visible or conditioned */}
        <AgentConsole logs={logs} />
      </main>
    </div>
  );
};

export default App;
